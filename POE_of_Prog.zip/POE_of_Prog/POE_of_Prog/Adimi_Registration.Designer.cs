﻿namespace POE_of_Prog
{
    partial class Adimi_Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            Firstname = new TextBox();
            Lastname = new TextBox();
            Address = new TextBox();
            Email = new TextBox();
            Phone = new TextBox();
            Username = new TextBox();
            Password = new TextBox();
            sutmit = new Button();
            button2 = new Button();
            label9 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(184, 68);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(50, 20);
            label1.TabIndex = 0;
            label1.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(184, 110);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(70, 20);
            label2.TabIndex = 1;
            label2.Text = "Surname";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(182, 142);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(0, 20);
            label3.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(184, 154);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(63, 20);
            label4.TabIndex = 3;
            label4.Text = "Address";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(182, 198);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(46, 20);
            label5.TabIndex = 4;
            label5.Text = "Email";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(182, 234);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(78, 20);
            label6.TabIndex = 5;
            label6.Text = "Phone No";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(182, 270);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(81, 20);
            label7.TabIndex = 6;
            label7.Text = "UserName";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(178, 308);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(73, 20);
            label8.TabIndex = 7;
            label8.Text = "Password";
            // 
            // Firstname
            // 
            Firstname.Location = new Point(299, 64);
            Firstname.Margin = new Padding(4);
            Firstname.Name = "Firstname";
            Firstname.Size = new Size(186, 27);
            Firstname.TabIndex = 8;
            // 
            // Lastname
            // 
            Lastname.Location = new Point(299, 106);
            Lastname.Margin = new Padding(4);
            Lastname.Name = "Lastname";
            Lastname.Size = new Size(186, 27);
            Lastname.TabIndex = 9;
            // 
            // Address
            // 
            Address.Location = new Point(299, 150);
            Address.Margin = new Padding(4);
            Address.Name = "Address";
            Address.Size = new Size(186, 27);
            Address.TabIndex = 10;
            // 
            // Email
            // 
            Email.Location = new Point(299, 190);
            Email.Margin = new Padding(4);
            Email.Name = "Email";
            Email.Size = new Size(186, 27);
            Email.TabIndex = 11;
            // 
            // Phone
            // 
            Phone.Location = new Point(299, 228);
            Phone.Margin = new Padding(4);
            Phone.Name = "Phone";
            Phone.Size = new Size(186, 27);
            Phone.TabIndex = 12;
            // 
            // Username
            // 
            Username.Location = new Point(299, 266);
            Username.Margin = new Padding(4);
            Username.Name = "Username";
            Username.Size = new Size(186, 27);
            Username.TabIndex = 13;
            // 
            // Password
            // 
            Password.Location = new Point(299, 306);
            Password.Margin = new Padding(4);
            Password.Name = "Password";
            Password.Size = new Size(186, 27);
            Password.TabIndex = 14;
            // 
            // sutmit
            // 
            sutmit.BackColor = SystemColors.ControlDark;
            sutmit.Location = new Point(259, 370);
            sutmit.Margin = new Padding(4);
            sutmit.Name = "sutmit";
            sutmit.Size = new Size(97, 30);
            sutmit.TabIndex = 15;
            sutmit.Text = "Submit";
            sutmit.UseVisualStyleBackColor = false;
            sutmit.Click += sutmit_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ButtonShadow;
            button2.Location = new Point(389, 370);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Size = new Size(97, 30);
            button2.TabIndex = 16;
            button2.Text = "Back";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold);
            label9.Location = new Point(295, 16);
            label9.Name = "label9";
            label9.Size = new Size(115, 25);
            label9.TabIndex = 17;
            label9.Text = "Registration";
            // 
            // Adimi_Registration
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(661, 599);
            Controls.Add(label9);
            Controls.Add(button2);
            Controls.Add(sutmit);
            Controls.Add(Password);
            Controls.Add(Username);
            Controls.Add(Phone);
            Controls.Add(Email);
            Controls.Add(Address);
            Controls.Add(Lastname);
            Controls.Add(Firstname);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "Adimi_Registration";
            Text = "Adimi_Registration";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox Firstname;
        private TextBox Lastname;
        private TextBox Address;
        private TextBox Email;
        private TextBox Phone;
        private TextBox Username;
        private TextBox Password;
        private Button sutmit;
        private Button button2;
        private Label label9;
    }
}